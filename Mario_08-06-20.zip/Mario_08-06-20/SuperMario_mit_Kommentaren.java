import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 01.06.2020
 * @Marc St�we, Lars von Bandel, Niklas Goldschmidt und Dominik Schulz
 *
 * Bekannte Bugs/Baustellen:
  * Springen resettet sich nicht vern�nftig, Fliegen m�glich (muss noch umgecodet werden, gerade sehr unelegant gel�st)
  * groundpanel bewegt sich nicht mit
  * Marios Boxinteraktionen sind nicht fertig
  * Schleichen muss noch integriert werden
  * Zielabfrage / Wie wird das Level beendet?
  * Programmieren eines Gegners und weiterer Spielelemente
 */

public class SuperMario_mit_Kommentaren extends JApplet {
  //Benutzte Objekte (Charakter, Box, PowerUp, Boden und ein Array zum Speichern der zu bewegenden Panels wird definiert
  private JPanel marioCharacter = new JPanel(null, true);
  private JPanel eventBox = new JPanel(null, true);
  private JPanel powerUP = new JPanel(null, true);
  private JPanel ground = new JPanel(null, true);
  ArrayList<JPanel> panels = new ArrayList<JPanel>(); 
  //Definition zus�tzlicher Objekte
  private Timer timer_update = new Timer(1000, null);
  private JButton bStart = new JButton();
  //Essentielle globale Bewegungsvariablen f�r Mario
  int jumpSpeed = 2;
  int moveSpeed;
  int maxJumpHeight = 220;
  int currentJumpHeight = 0;
  //Abfragevariablen f�r Marios Aktionen
  boolean jumping = false;
  boolean moveRight = false;
  boolean moveLeft = false;


  public void init() {
    Container cp = getContentPane();
    cp.setLayout(null);
    cp.setSize(1080, 720);
    cp.setBounds(0, 0, 1295, 720);
    panels.add(eventBox);
    panels.add(powerUP);
    panels.add(ground);
    powerUP.hide();
    KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(new KeyEventDispatcher() { // Event f�r die Abfrage der Tasteneingaben wird definiert

      @Override
      public boolean dispatchKeyEvent(KeyEvent ke) {
        switch (ke.getID()) {
        case KeyEvent.KEY_PRESSED: // sollte irgendeine Taste heruntergedr�ckt werden, wird folgender Code abgefragt
          if (ke.getKeyCode() == KeyEvent.VK_SPACE) { // Wenn die heruntergedr�ckte Taste die Leertaste ist
            jumping = true;
            if (contactwithbox_top()) {
              powerUP.show();
            }
          }
          if (ke.getKeyCode() == KeyEvent.VK_D) {
            moveSpeed = -2;
            moveRight = true; // folgender Befehl wird ausgef�hrt, sollte Taste 'D' gedr�ckt werden
            // moveSidewards(movespeed);
          }
          if (ke.getKeyCode() == KeyEvent.VK_A) { // folgender Befehl wird ausgef�hrt, sollte Taste 'A' gedr�ckt werden
            moveSpeed = 2;
            moveLeft = true;
            // moveSidewards(movespeed);
          }
          break;

        case KeyEvent.KEY_RELEASED: // Folgendes passiert, sollte eine Taste losgelassen werden
          if (ke.getKeyCode() == KeyEvent.VK_D) {
            moveRight = false;
          }
          if (ke.getKeyCode() == KeyEvent.VK_A) {
            moveLeft = false;
          }
          break;
        }
        return false;
      }
    });
    // Anfang Komponenten

    marioCharacter.setBounds(230, 350, 100, 100);
    marioCharacter.setOpaque(true);
    marioCharacter.setBackground(Color.CYAN);

    cp.add(marioCharacter);
    eventBox.setBounds(230, 450, 50, 50);
    eventBox.setOpaque(true);
    eventBox.setBackground(new Color(0xFFC800));
    cp.add(eventBox);
    powerUP.setBounds(eventBox.getX(), eventBox.getY() - eventBox.getHeight(), 50, 50);
    powerUP.setOpaque(true);
    powerUP.setBackground(Color.CYAN);
    cp.add(powerUP);
    timer_update.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        timer_update_ActionPerformed(evt);
      }
    });
    timer_update.setRepeats(true);
    timer_update.setInitialDelay(0);
    bStart.setBounds(1172, 7, 75, 25);
    bStart.setText("Start");
    bStart.setMargin(new Insets(2, 2, 2, 2));
    bStart.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        bStart_ActionPerformed(evt);
      }
    });
    cp.add(bStart);
    timer_update.setDelay(1);
    ground.setBounds(0, 630, 5000, 55);
    ground.setOpaque(true);
    ground.setBackground(Color.GREEN);
    cp.add(ground);
    // Ende Komponenten

  } // end of init
  
  //Methode f�r Bewegungen wird erstellt
  public void move(int a) {
    //wenn Mario nach links oder rechts geht, verschiebt sich der Hintergrund / die Panels passend
    if (moveRight == true || moveLeft == true) {
      for (int i = 0; i < panels.size(); i++) {
        JPanel panel = (JPanel) panels.toArray()[i];
        panel.setLocation(panel.getX() + moveSpeed, panel.getY());
      }
    }
    // Beim Springen wird Marios Y-Koordinate verschoben
    if (jumping == true && currentJumpHeight <= maxJumpHeight) {
      marioCharacter.setLocation(marioCharacter.getX(), (marioCharacter.getY() - jumpSpeed));
      currentJumpHeight = currentJumpHeight + jumpSpeed;
    } 
  }

  // Anfang Methoden
  public void timer_update_ActionPerformed(ActionEvent evt) {
    // Methoden zu Bewegung und die Schwerkraft werden bei jedem Tick des Timers (jede Millisekunde) abgerufen
    this.move(moveSpeed);
    this.variablereset();
    this.gravity();
  } // end of timer_update_ActionPerformed

  public void bStart_ActionPerformed(ActionEvent evt) {
    // Updatetimer wird gestartet
    timer_update.start();
  }

  public void variablereset() {
    // Wenn Mario bei seiner maximalen Sprungh�he angekommen ist, wird es auf nicht mehr springend gesetzt, damit die Schwerkraft wieder greift
    if (currentJumpHeight == maxJumpHeight) {
      currentJumpHeight = 0;
      jumping = false;
    } // end of if
  }

  public void gravity() {
    // Sollte Mario nicht im Sprung sein oder auf dem Boden stehen, wird er nach unten verschoben, bis er den Boden ber�hrt
    if (jumping == false && this.contactwithground_top() == false) {
      marioCharacter.setLocation(marioCharacter.getX(), marioCharacter.getY() + jumpSpeed);
    } // end of if
  }
  //Wenn Mario den Boden ber�hrt (Marios Y + H�he = Y des Bodes), gibt die Methode true aus, um die Schwerkraft zu stoppen
  public boolean contactwithground_top() {
    if ((marioCharacter.getY() + marioCharacter.getHeight()) == ground.getY()) {
      return true;
    } else {
      return false;
    } 
  }
  //Noch nicht integriert
  public boolean contactwithbox_top() {
    if (marioCharacter.getY() - 100 <= eventBox.getY()
        && (marioCharacter.getX() >= eventBox.getX() && marioCharacter.getX() <= eventBox.getX() + 50)) {
      return true;
    } else {
      return false;
    } 
  }

} 
